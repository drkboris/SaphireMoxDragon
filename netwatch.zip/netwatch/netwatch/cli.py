"""Command line interface.

Each feature is a subcommand. To add one later (say `diff` or `ports`):
  1. write a `cmd_<name>(args)` function
  2. register it in `build_parser()` with set_defaults(func=cmd_<name>)
"""

import argparse
import asyncio
import json
import shutil
from pathlib import Path

from .config import DEFAULT_CONFIG, load_networks, resolve_targets
from .enrich import enrich_hosts
from .scanner import sweep
from .storage import DEFAULT_DATA_DIR, build_run_record, save_run


def cmd_sweep(args: argparse.Namespace) -> int:
    try:
        networks = load_networks(args.config) if args.config.exists() else {}
        targets = resolve_targets(args.networks, networks)
    except ValueError as exc:
        print(f"error: {exc}")
        return 2
    if not targets:
        print(f"error: no networks to scan (looked for {args.config})")
        return 2

    if args.enrich and not shutil.which("nmap"):
        print("error: --enrich needs nmap (Fedora: sudo dnf install nmap)")
        return 2

    # label -> list of HostResult, scanned one network at a time
    all_results = {}
    for label, cidr in targets.items():
        results = asyncio.run(sweep(cidr, concurrency=args.concurrency))
        if args.enrich:
            asyncio.run(enrich_hosts([r for r in results if r.alive]))
        all_results[label] = results

    record = build_run_record(targets, all_results)
    saved_to = None if args.no_save else save_run(record, args.data_dir)

    if args.json:
        print(json.dumps(record, indent=2))
        return 0

    for label, results in all_results.items():
        alive = [r for r in results if r.alive]
        print(f"\n== {label} ({targets[label]}) ==")
        print(f"{'IP ADDRESS':<16}{'RTT(ms)':>8}  {'HOSTNAME':<26}{'VENDOR':<22}PORTS")
        for r in alive:
            ports = ",".join(r.open_ports) or "-"
            print(
                f"{r.ip:<16}{r.rtt_ms:>8}  {(r.hostname or '-'):<26}"
                f"{(r.vendor or '-'):<22}{ports}"
            )
        print(f"{len(alive)} of {len(results)} hosts responded")
    if saved_to:
        print(f"\nSaved to {saved_to}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="netwatch", description="Home network tools")
    sub = parser.add_subparsers(dest="command", required=True)

    p_sweep = sub.add_parser("sweep", help="ping sweep one or more networks")
    p_sweep.add_argument(
        "networks",
        nargs="*",
        help="names from the config file or raw CIDRs; omit to scan all configured networks",
    )
    p_sweep.add_argument(
        "--config", type=Path, default=DEFAULT_CONFIG, help="networks file (default: networks.toml)"
    )
    p_sweep.add_argument("-c", "--concurrency", type=int, default=64)
    p_sweep.add_argument("--json", action="store_true", help="output JSON")
    p_sweep.add_argument(
        "--enrich", action="store_true", help="run nmap on live hosts for hostname/ports/MAC"
    )
    p_sweep.add_argument("--no-save", action="store_true", help="do not write results to disk")
    p_sweep.add_argument(
        "--data-dir", type=Path, default=DEFAULT_DATA_DIR, help="where run history is saved"
    )
    p_sweep.set_defaults(func=cmd_sweep)

    return parser


def main() -> int:
    args = build_parser().parse_args()
    return args.func(args)
