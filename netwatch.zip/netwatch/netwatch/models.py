"""Data structures shared across netwatch modules."""

from dataclasses import dataclass, asdict, field


@dataclass
class HostResult:
    ip: str
    alive: bool
    rtt_ms: float | None = None  # round trip time, None if no reply
    # Filled in by enrichment (nmap). All optional, so a plain sweep still works.
    hostname: str | None = None
    mac: str | None = None
    vendor: str | None = None
    os_guess: str | None = None
    open_ports: list[str] = field(default_factory=list)  # e.g. "22/ssh"

    def to_dict(self) -> dict:
        return asdict(self)
