"""Async ping sweep.

We shell out to the system `ping` command instead of crafting ICMP packets,
because raw sockets need root. The command-building is the only part that
differs per OS, so it lives in one small function.
"""

import asyncio
import ipaddress
import platform
import time
from collections.abc import Awaitable, Callable

from .models import HostResult

# A "pinger" takes an IP string and returns a HostResult.
# Swapping this out (for tests, or a TCP-connect check later) is the main
# extension point of the scanner.
Pinger = Callable[[str], Awaitable[HostResult]]


def build_ping_command(ip: str, timeout_s: float = 1.0) -> list[str]:
    """Return the ping command for the current OS."""
    system = platform.system()
    if system == "Windows":
        return ["ping", "-n", "1", "-w", str(int(timeout_s * 1000)), ip]
    if system == "Darwin":  # macOS takes the timeout in milliseconds
        return ["ping", "-c", "1", "-W", str(int(timeout_s * 1000)), ip]
    return ["ping", "-c", "1", "-W", str(max(1, int(timeout_s))), ip]  # Linux


async def ping_host(ip: str, timeout_s: float = 1.0) -> HostResult:
    """Ping a single host once."""
    cmd = build_ping_command(ip, timeout_s)
    start = time.perf_counter()
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        # Hard cap so one stuck process can never hang the whole sweep.
        await asyncio.wait_for(proc.wait(), timeout=timeout_s + 2)
    except (asyncio.TimeoutError, FileNotFoundError):
        return HostResult(ip=ip, alive=False)

    if proc.returncode == 0:
        rtt = (time.perf_counter() - start) * 1000
        return HostResult(ip=ip, alive=True, rtt_ms=round(rtt, 1))
    return HostResult(ip=ip, alive=False)


def expand_network(cidr: str) -> list[str]:
    """Turn '192.168.1.0/24' into a list of usable host IPs."""
    network = ipaddress.ip_network(cidr, strict=False)
    return [str(ip) for ip in network.hosts()]


async def sweep(
    cidr: str,
    concurrency: int = 64,
    pinger: Pinger = ping_host,
) -> list[HostResult]:
    """Ping every host in a network, `concurrency` at a time."""
    ips = expand_network(cidr)
    semaphore = asyncio.Semaphore(concurrency)

    async def bounded(ip: str) -> HostResult:
        async with semaphore:
            return await pinger(ip)

    results = await asyncio.gather(*(bounded(ip) for ip in ips))
    # Sort numerically by IP rather than as strings ("10" before "9").
    return sorted(results, key=lambda r: ipaddress.ip_address(r.ip))
